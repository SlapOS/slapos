libcloud
========

Slapified recipe to interact with any libcloud supported IaaS system
