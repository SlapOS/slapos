<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Access to phpmyadmin</h3>
      </div>
      <div class="panel-body">
        <div class="panel-body">
        <p class='data'>URL: <a href="<?php echo MYSQL_URL ?>" target='_blank' title='Access to website'><?php echo MYSQL_URL ?></a></p>
        <p class='data'>IPv6 URL: <a href="<?php echo MYSQL_BACKEND_URL ?>" target='_blank' title='Access to website'><?php echo MYSQL_BACKEND_URL ?></a></p>
      </div>
      </div>
  </div>

<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Database Connection informations</h3>
      </div>
      <div class="panel-body">
        <p class='data'>DB User: <?php echo DB_USER ?></a></p>
        <p class='data'>DB Password: <?php echo DB_PASSWORD ?></a></p>        
        <p class='data'>DB Name: <?php echo DB_NAME ?></a></p>
        <p class='data'>DB Host: <?php echo DB_HOST ?></a></p>
        <p class='data'>DB Port: <?php echo DB_PORT ?></a></p>
        <p class='details'>All this informations would help you to configure your site with MySQL Database.
        <br/>Note: It's not possible to change database password.</p>
      </div>
  </div>