<?php
 
 
function read_file($file, $lines) {
    //global $fsize;
    $handle = fopen($file, "r");
    $linecounter = $lines;
    $pos = -2;
    $beginning = false;
    $text = array();
    while ($linecounter > 0) {
        $t = " ";
        while ($t != "\n") {
            if(fseek($handle, $pos, SEEK_END) == -1) {
                $beginning = true; 
                break; 
            }
            $t = fgetc($handle);
            $pos --;
        }
        $linecounter --;
        if ($beginning) {
            rewind($handle);
        }
        $text[$lines-$linecounter-1] = fgets($handle);
        if ($beginning) break;
    }
    fclose ($handle);
    return array_reverse($text);
}

?>


  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Displaying last <?php echo $lineCount ?> lines of file <?php echo $file_name ?></h3>
      </div>
      <div class="panel-body">
        <div class="panel-body">
        <?php 
        $lines = read_file($filepath, $lineCount);
        foreach ($lines as $line) {
            echo $line."<br/>";
        }
        ?>
        <p class='details'></p>
      </div>
      </div>
  </div>