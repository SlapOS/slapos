<?php


?>

<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Connection informations</h3>
      </div>
      <div class="panel-body">
        <p class='data'>WebSite URL: <a href="<?php echo PUBLIC_URL ?>" target='_blank' title='Access to website'><?php echo PUBLIC_URL ?></a></p>
        <p class='data'>IPv6 URL: <a href="<?php echo PUBLIC_BACKEND_URL ?>" target='_blank' title='Access to website'><?php echo PUBLIC_BACKEND_URL ?></a></p>
      </div>
  </div>

<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Ready to deploy and use</h3>
      </div>
      <div class="panel-body">
        <div class='list-content'>
          <div class='list'>
            <span>
              <input type="radio" name="applist" value="wordpress" />
              <img src="images/wp-header-logo.png" style="width: 200px;"/>
            </span>
          </div>
          <div class='list'>
            <span>
              <input type="radio" name="applist" value="joomla" />
              <img src="images/joomla.png" style="width: 150px;"/>
            </span>
          </div>
          <div class='list'>
            <span>
              <input type="radio" name="applist" value="drupal" />
              <img src="images/drupal.png" style="height: 120px;"/>
            </span>
          </div>
          <div class='list'>
            <span>
              <input type="radio" name="applist" value="prestashop" />
              <img src="images/prestashop.png" style="width: 200px;"/>
            </span>
          </div>
        </div>
        <div class='clear'></div>
        <br/>
        <span class="btn btn-primary start" id="deployApp">
          <i class="glyphicon glyphicon-upload"></i>
          <span>Deploy Application</span>
        </span>
      </div>
  </div>

<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Upload your files</h3>
      </div>
      <div class="panel-body">
      	<p>Upload your sources files to server folder. If you have uploaded a ZIP tarball
        then, it will be extracted automatically. You should manually move extracted files from upload directory to your "public_html" folder
        using Ajaxplorer.</p>
      	<br/>
          <!-- The fileinput-button span is used to style the file input field as button -->
	    <span class="btn btn-success fileinput-button">
	        <i class="glyphicon glyphicon-plus"></i>
	        <span>Add Files...</span>
	        <!-- The file input field used as target for the file upload widget -->
	        <input id="fileupload" type="file" name="files[]" multiple>
	    </span>
      <span class="btn btn-primary start" id="goAjaxplorer">
          <i class="glyphicon glyphicon-upload"></i>
          <span>Open Ajaxplorer</span>
      </span>
	    <br>
	    <br>
	    <!-- The global progress bar -->
	    <div id="progress" class="progress">
	        <div class="progress-bar progress-bar-success"></div>
	    </div>
	    <!-- The container for the uploaded files -->
	    <div id="files" class="files"></div>
	    <br>
      </div>
  </div>