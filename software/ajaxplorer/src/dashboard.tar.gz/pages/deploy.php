<?php

require_once(dirname(__FILE__) . '/../' . 'config.php');

function recurse_copy($src, $dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $app = $_REQUEST['app'];
  $result = "{code: 1}";
  if (count(glob(WWW_FOLDER."*")) === 0 ) {
    if (isset($app) && !empty($app) ) {
      switch ($app) {
        case "wordpress":
          recurse_copy(WP_FOLDER, WWW_FOLDER);
          break;
        case "drupal":
          recurse_copy(DRUPAL_FOLDER, WWW_FOLDER);
          break;
        case "joomla":
          recurse_copy(JOOMLA_FOLDER, WWW_FOLDER);
          break;
        case "prestashop":
          recurse_copy(PRESTASHOP_FOLDER, WWW_FOLDER);
          break;
        default: $result = "{code: 0, msg: 'Unknow application to deploy'}";
      }
    }
    else $result = "{code: 0, msg: 'Parameter is not defined'}";
  }
  else $result = "{code: 2, msg: 'Folder public_hmtl is not empty'}";
  echo $result;
}
else echo "{code: 0, msg: 'Method is not allowed'}";
