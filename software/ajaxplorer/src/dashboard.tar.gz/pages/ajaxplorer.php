<div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Ajaxplorer access link</h3>
      </div>
      <div class="panel-body">
        <div class="panel-body">
        <p class='data'>URL: <a href="<?php echo FILE_URL ?>" target='_blank' title='Access to website'><?php echo FILE_URL ?></a></p>
        <p class='data'>IPv6 URL: <a href="<?php echo FILE_BACKEND_URL ?>" target='_blank' title='Access to website'><?php echo FILE_BACKEND_URL ?></a></p>
      </div>
      </div>
  </div>
  
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Informations about File Manager</h3>
      </div>
      <div class="panel-body">
        <div class="panel-body">
        <img src="img/AjaXplorer.jpg" style="width: 150px;float: left;margin-right: 20px;margin-top: 15px;"/>
        <p class='details' style="line-height: 25px;">
        AjaXplorer is a cloud storage application that would help you to configure your website. You should upload the tarball of your source code and extract it into "public_html" folder in order to access to your website.<br/>
        You can also customize your website by editing your source code directly in AjaXplorer.
        </p>
        <div style="clear:both"></div>
        <div class='line'></div>
        <br/>
        <p><strong>Note: </strong> The default login for Ajaxplorer is <strong>admin</strong>, password is <strong>insecure</strong>. 
        Remember to change it as soon as possible.</p>
      </div>
      </div>
  </div>