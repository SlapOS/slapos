/*jslint undef: true */
/*global $, document, window */
/* vim: set et sts=4: */

$(document).ready(function () {
  "use strict";
  
  function requestAjax(){

    var jqxhr = $.ajax({
        type: "POST",
        url: '/pages/deploy.php' ,
        data: {app: $("input[name='applist']:checked").val()}       
        })
      .done(function(data) {
        if (data.indexOf("{code: 2,") !== -1) {
          alert("Error: Folder public_html is not empty. You have already deployed an application!");
        } else if (data.indexOf("{code: 1}") === -1) {
          alert("Error: Incorrect parameters, cannot deploy this application");
        } else {
          alert("You can now open your new website. Enjoy!");
        }
      })
      .fail(function(jqXHR, exception) {
        if (jqXHR.status == 404) {
            alert("Requested page not found. [404]");
        } else if (jqXHR.status == 500) {
            alert("Internal Error. Cannot respond to your request, please check your parameters");
        } else {
            alert("An Error occured: \n" + jqXHR.responseText);
        }
      })
      .always(function() {
        //return result;
      });
  }
  
  $("#deployApp").click( function () {
    if ( $("input[name='applist']:checked").val() ) {
      requestAjax();
    }
    return false;
  });
  
  $("#logout").click(function(){
    (function(safeLocation){
      var outcome, u, m;
      // IE has a simple solution for it - API:
      try { outcome = document.execCommand("ClearAuthenticationCache") }catch(e){}
      // Other browsers need a larger solution - AJAX call with special user name - 'logout'.
      if (!outcome) {
          // Let's create an xmlhttp object
          outcome = (function(x){
              if (x) {
                  // the reason we use "random" value for password is 
                  // that browsers cache requests. changing
                  // password effectively behaves like cache-busing.
                  x.open("HEAD", safeLocation || location.href, true, "logout", (new Date()).getTime().toString());
                  x.send("");
                  // x.abort()
                  return 1 // this is **speculative** "We are done." 
              } else {
                  return
              }
          })(window.XMLHttpRequest ? new window.XMLHttpRequest() : ( window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : u ));
      }
      if (!outcome) {
          m = "Your browser is too old or too weird to support log out functionality. Close all windows and restart the browser.";
      }
      if (m){
        alert(m);
      }
      // return !!outcome
    })(/*if present URI does not return 200 OK for GET, set some other 200 OK location here*/)
  });
    
  $("span#goAjaxplorer").click( function () {
    location.href="index.php?p=ajaxplorer";
  });
  
  $("#site").click(function(){
    location.href="index.php?p=site";    
  });
  
  $("#db").click(function(){
    location.href="index.php?p=db";    
  });
  
  $("#filemanager").click(function(){
    location.href="index.php?p=ajaxplorer";    
  });
  
  $("#errorlog").click(function(){
    location.href="index.php?p=errorlog";    
  });
  
  $("#accesslog").click(function(){
    location.href="index.php?p=accesslog";    
  });
  
  
    
});