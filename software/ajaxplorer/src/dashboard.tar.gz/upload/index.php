<?php
/*
 * jQuery File Upload Plugin PHP Example 5.14
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */
  
require_once(dirname(__FILE__) . '/../' . 'config.php');

$options = array(
    'upload_dir' => UPLOAD_FOLDER,
  );
require('UploadHandler.php');
$upload_handler = new UploadHandler($options);
