<?php
/** Absolute path to the Site directory. */
if ( !defined('ABSPATH') )
  define('ABSPATH', dirname(__FILE__) . '/');
	
require_once(ABSPATH . 'config.php');
$page = $_REQUEST['p'];
if (!isset($page) || empty($page) ) {
  $page = 'site';
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<TITLE>SlapOS LAMP dashboard</TITLE>	
	<link rel="stylesheet" href="css/jquery.fileupload.css">
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link type="text/css" rel="stylesheet" href="css/style.css" />
	<SCRIPT type="text/javascript" src="js/jquery-1.10.2.min.js"></SCRIPT>
	<SCRIPT type="text/javascript" src="js/jquery.layout-latest.min.js"></SCRIPT>
  <SCRIPT type="text/javascript" src="js/site.js"></SCRIPT>
	<SCRIPT type="text/javascript">
	$(document).ready(function () {
		$("body").layout({
		   center: {
		      fxName:                "none"
		   ,  togglerLength_closed:  "100%"
		   ,   size:                 "auto"
		   }
		,  west: {
		      fxName:                "none"
		   ,  togglerLength_closed:  "100%"
		   ,  size: 250
		   ,  togglerLength_open:	 0
		   ,  spacing_open:			 4
		   },
			resizable: false,
			closable: false
		,	center__childOptions: {
				center__paneSelector:	".inner-center"
			,	north__paneSelector:	".inner-north"
			,	north__size:			113
			,	center__size:			"auto"
			,	spacing_open:			0  // ALL panes
			,	spacing_closed:			2  // ALL panes
			}

		});
	});
	</SCRIPT>	
</HEAD>
<BODY>
<DIV class="ui-layout-center">
	<div class="inner-north">
		<div class="title_head">
			<h2>LAMP Service Dashboard</h2>
		</div>
		<div class="title-main"><h3>
    <?php
    switch($page){
      case "site": echo "Configure and access to  your website"; break;
      case "db": echo "Database access and management"; break;
      case "ajaxplorer": echo "Access file manager"; break;
      case  "errorlog": echo "View apache error log file"; break;
      case  "accesslog": echo "View apache access log file"; break;
      default: echo "Page not found!";
    }
    
    ?>
    </h3></div>
	</div>
	<div class="inner-center">
		<div id="content">
    <?php
    switch($page){
      case "site": require_once(ABSPATH . '/pages/site.php'); break;
      case "db": require_once(ABSPATH . '/pages/db.php'); break;
      case "ajaxplorer": require_once(ABSPATH . '/pages/ajaxplorer.php'); break;
      case  "errorlog": 
        $filepath = APACHE_ERROR_FILE;
        $lineCount = 1500;
        $file_name = "apache_error.log";
        require_once(ABSPATH . '/pages/log.php'); break;
      case  "accesslog": 
        $filepath = APACHE_ACCESS_FILE;
        $lineCount = 1500;
        $file_name = "apache_access.log";
        require_once(ABSPATH . '/pages/log.php'); break;
      default:
    }
    ?>
		    
		</div>
	</div>
</DIV>
<DIV class="ui-layout-west">
	<div id='left'>
		<div class='head'>
			<img src="images/slapos.png" border='0' />
		</div>
		<div class='menu'>
		<ul>
			<li id="site" style="border-top: 1px solid #8E9091;" <?php if($page =='site') echo "class='active'" ?>>Website management</li>
			<li id="db" <?php if($page =='db') echo "class='active'" ?>>Database management</li>
			<li id="filemanager" <?php if($page =='ajaxplorer') echo "class='active'" ?>>Access to file manager</li>
			<li id="errorlog" <?php if($page =='errorlog') echo "class='active'" ?>>Apache Error Log</li>
      <li id="accesslog" <?php if($page =='accesslog') echo "class='active'" ?>>Apache Access Log</li>
      <li id="logout" style="border-top: 1px solid #8E9091; border-bottom: 1px solid #8E9091;">Disconnect</li>
		</ul>
	</div>
	</div>
</DIV>
<!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
<script src="js/vendor/jquery.ui.widget.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="js/jquery.fileupload-process.js"></script>
<!-- The File Upload validation plugin -->
<script src="js/jquery.fileupload-validate.js"></script>
<script>

/*jslint unparam: true, regexp: true */
/*global window, $ */
$(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload/',
        uploadButton = $('<button/>')
            .addClass('btn btn-primary')
            .prop('disabled', true)
            .text('Processing...')
            .on('click', function () {
                var $this = $(this),
                    data = $this.data();
                $this
                    .off('click')
                    .text('Abort')
                    .on('click', function () {
                        $this.remove();
                        data.abort();
                    });
                data.submit().always(function () {
                    $this.remove();
                });
            });
    $('#fileupload').fileupload({
        url: url,
        dataType: 'json',
        autoUpload: false,        
        maxFileSize: 20000000, // 20 MB
        // Enable image resizing, except for Android and Opera,
        // which actually support image resizing, but fail to
        // send Blob objects via XHR requests:
        disableImageResize: /Android(?!.*Chrome)|Opera/
            .test(window.navigator.userAgent),
        previewMaxWidth: 100,
        previewMaxHeight: 100,
        previewCrop: true
    }).on('fileuploadadd', function (e, data) {
        data.context = $('<div/>').appendTo('#files');
        $.each(data.files, function (index, file) {
            var node = $('<p/>')
                    .append($('<span/>').text(file.name));
            if (!index) {
                node
                    .append('<br>')
                    .append(uploadButton.clone(true).data(data));
            }
            node.appendTo(data.context);
        });
    }).on('fileuploadprocessalways', function (e, data) {
        var index = data.index,
            file = data.files[index],
            node = $(data.context.children()[index]);
        if (file.preview) {
            node
                .prepend('<br>')
                .prepend(file.preview);
        }
        if (file.error) {
            node
                .append('<br>')
                .append($('<span class="text-danger"/>').text(file.error));
        }
        if (index + 1 === data.files.length) {
            data.context.find('button')
                .text('Upload')
                .prop('disabled', !!data.files.error);
        }
    }).on('fileuploadprogressall', function (e, data) {
        var progress = parseInt(data.loaded / data.total * 100, 10);
        $('#progress .progress-bar').css(
            'width',
            progress + '%'
        );
    }).on('fileuploaddone', function (e, data) {
        $.each(data.result.files, function (index, file) {
            if (file.url) {
                var elt = $('<div>');                
                    //.attr('target', '_blank')
                    //.prop('href', file.url);
                $(data.context.children()[index])
                    .wrap(elt);
            } else if (file.error) {
                var error = $('<span class="text-danger"/>').text(file.error);
                $(data.context.children()[index])
                    .append('<br>')
                    .append(error);
            }
        });
    }).on('fileuploadfail', function (e, data) {
        $.each(data.files, function (index, file) {
            var error = $('<span class="text-danger"/>').text('File upload failed.');
            $(data.context.children()[index])
                .append('<br>')
                .append(error);
        });
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
});
</script>
</BODY>
</HTML>