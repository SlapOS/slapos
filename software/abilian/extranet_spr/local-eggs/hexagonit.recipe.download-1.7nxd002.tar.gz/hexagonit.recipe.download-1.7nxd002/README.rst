*******************************
Download recipe for zc.buildout
*******************************

.. contents::

The recipe downloads packages from the net and extracts them on the
filesystem. It is based on the gocept.download_ recipe with a few
additional features.

 * Github page: http://github.com/hexagonit/hexagonit.recipe.download
 * Clone URL: git://github.com/hexagonit/hexagonit.recipe.download.git
 * Issue tracker: http://github.com/hexagonit/hexagonit.recipe.download/issues
 * Travis build: |travis|

Supported Python versions: 2.6, 2.7, 3.2, 3.3

Supported zc.buildout versions: 1.x, 2.x

.. |travis| image:: https://api.travis-ci.org/hexagonit/hexagonit.recipe.download.png

.. _gocept.download: http://pypi.python.org/pypi/gocept.download
