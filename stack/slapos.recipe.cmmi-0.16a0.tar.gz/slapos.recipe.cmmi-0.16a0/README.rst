********************************************
Recipe for compiling and installing software
********************************************

.. contents::

The recipe provides the means to compile and install source distributions
using ``configure`` and ``make`` and other similar tools. It is inspired by
the hexagonit.recipe.cmmi_ recipe but provides more control over the build process.

.. _hexagonit.recipe.cmmi : http://pypi.python.org/pypi/hexagonit.recipe.cmmi
